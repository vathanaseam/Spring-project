package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data

public class Commune{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer numOfCommune;
    private Integer cId;
    private Integer numOfSongkat;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_dId", referencedColumnName = "dId")
    private District district;


}
class Communes{
    private int cIds;
    private int numOfCommunes;
    private int numOfSongkats;

    Communes(int cIds, int numOfCommunes, int numOfSongkats){
        this.cIds = cIds;
        this.numOfCommunes = numOfCommunes;
        this.numOfSongkats = numOfSongkats;

    }
    public int getcIds(){
        return cIds;
    }
    public int getnumOfCommunes(){
        return numOfCommunes;
    }
    public int getnumOfSongkats(){
        return numOfSongkats;
    }

}
class CRUDcommune{
    public static void main(String[] args) {
        List<Communes> c = new ArrayList<Communes>();
        Scanner s = new Scanner(System.in);
        int ch;
        do {
            System.out.println("1. INSERT");
            System.out.println("2. UPDATE");
            System.out.println("3. DELETE");
            System.out.println("4. SELECT");
            ch = s.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter Commune ID");
                    int cIds = s.nextInt();
                    System.out.println("Enter Number of Commune");
                    int numOfCommunes = s.nextInt();
                    System.out.println("Enter Number of Songkat");
                    int numOfSongkats = s.nextInt();
                    c.add(new Communes(cIds,numOfCommunes, numOfSongkats));

                    break;
                case 2:
                    System.out.println("---------------------");
                    Iterator<Communes> i = c.iterator();
                    while (i.hasNext()) {
                        Communes e = i.next();
                        System.out.println(e);
                    }
                    System.out.println("--------------------------");
                    break;
                case 3:
                    boolean found = false;
                    System.out.println("Enter Commune to Search");
                    int provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Communes e = i.next();
                        if (e.getcIds() == provincesId) {
                            System.out.println(e);
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    }
                    System.out.println("----------------");
                    break;
                case 4:
                    found = false;
                    System.out.println("Enter Commune to Delete");
                    cIds = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Communes e = i.next();
                        if (e.getcIds() == cIds) {
                            i.remove();
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is deleted successfully");
                    }
                    System.out.println("----------------");
                    break;
                case 5:
                    found = false;
                    System.out.println("Enter Province to Update");
                    provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    ListIterator<Communes> li = c.listIterator();
                    while (li.hasNext()) {
                        Communes e = li.next();
                        if (e.getcIds() == provincesId) {
                            System.out.println("Enter the new amount Communes");
                            numOfCommunes = s.nextInt();
                            System.out.println("Enter the new amount Songkat");
                            numOfSongkats = s.nextInt();

                            li.set(new Communes(numOfCommunes, numOfSongkats, provincesId));
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is updated successfully");
                    }
                    System.out.println("----------------");
                    break;
            }

        }while (ch != 0) ;

    }

}
