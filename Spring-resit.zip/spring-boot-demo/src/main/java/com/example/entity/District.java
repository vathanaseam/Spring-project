package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data

public class District {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private Integer dId;
    private Integer numOfKrong;
    private Integer numOfSrok;
    private Integer numOfKhan;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn
    private Province province;

}class Districts{
    private int dIds;
    private int numOfKrongs;
    private int numOfSroks;
    private int numOfKhans;

    Districts(int dIds, int numOfKrongs, int numOfSroks, int numOfKhans){
        this.dIds = dIds;
        this.numOfKrongs = numOfKrongs;
        this.numOfKhans = numOfKhans;
        this.numOfSroks = numOfSroks;

    }
    public int getdIds(){
        return dIds;
    }
    public int getNumOfKhans(){
        return numOfKhans;
    }
    public int getNumOfSroks(){
        return numOfSroks;
    }
    public int getNumOfKrongs(){
        return numOfKrongs;
    }
}
class CRUDdistrict {
    public static void main(String[] args) {
        List<Districts> c = new ArrayList<Districts>();
        Scanner s = new Scanner(System.in);
        int ch;
        do {
            System.out.println("1. INSERT");
            System.out.println("2. UPDATE");
            System.out.println("3. DELETE");
            System.out.println("4. SELECT");
            ch = s.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter District ID");
                    int dIds = s.nextInt();
                    System.out.println("Enter Number of Krong");
                    int numOfKrongs = s.nextInt();
                    System.out.println("Enter Number of Srok");
                    int numOfSroks = s.nextInt();
                    System.out.println("Enter Number of Khan");
                    int numOfKhans = s.nextInt();
                    c.add(new Districts(dIds, numOfKrongs, numOfSroks, numOfKhans));

                    break;
                case 2:
                    System.out.println("---------------------");
                    Iterator<Districts> i = c.iterator();
                    while (i.hasNext()) {
                        Districts e = i.next();
                        System.out.println(e);
                    }
                    System.out.println("--------------------------");
                    break;
                case 3:
                    boolean found = false;
                    System.out.println("Enter District to Search");
                    int provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Districts e = i.next();
                        if (e.getdIds() == provincesId) {
                            System.out.println(e);
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    }
                    System.out.println("----------------");
                    break;
                case 4:
                    found = false;
                    System.out.println("Enter District to Delete");
                    dIds = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Districts e = i.next();
                        if (e.getdIds() == dIds) {
                            i.remove();
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is deleted successfully");
                    }
                    System.out.println("----------------");
                    break;
                case 5:
                    found = false;
                    System.out.println("Enter Province to Update");
                    provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    ListIterator<Districts> li = c.listIterator();
                    while (li.hasNext()) {
                        Districts e = li.next();
                        if (e.getdIds() == provincesId) {
                            System.out.println("Enter the new amount Srok");
                            numOfSroks = s.nextInt();

                            System.out.println("Enter the new amount Krong");
                            numOfKrongs = s.nextInt();
                            System.out.println("Enter the new amount KHan");
                            numOfKhans = s.nextInt();


                            li.set(new Districts(numOfKhans, numOfSroks, numOfKrongs, provincesId));
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is updated successfully");
                    }
                    System.out.println("----------------");
                    break;
            }

        }while (ch != 0) ;

    }

}



