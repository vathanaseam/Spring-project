package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.*;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Village {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int numOfVillage;
    private int vId;

    @OneToMany
    @JoinColumn
    private Commune commune;

}
class Villages {
    private int vIds;
    private int numOfVillages;

    Villages(int numOfVillages, int vIds) {
        this.numOfVillages = numOfVillages;
        this.vIds = vIds;

    }

    public int getvId() {
        return vIds;
    }
    public int getNumOfVillages(){
        return numOfVillages;
    }
}
class CRUDvillage{
    public static void main(String[] args) {
        List<Villages> c = new ArrayList<Villages>();
        Scanner s = new Scanner(System.in);
        int ch;
        do {
            System.out.println("1. INSERT");
            System.out.println("2. UPDATE");
            System.out.println("3. DELETE");
            System.out.println("4. SELECT");
            ch = s.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter number of Village Id");
                    int vIds = s.nextInt();
                    System.out.println("Enter number of Village");
                    int numOfVillages = s.nextInt();

                    c.add(new Villages(vIds,numOfVillages));

                    break;
                case 2:
                    System.out.println("---------------------");
                    Iterator<Villages> i = c.iterator();
                    while (i.hasNext()) {
                        Villages e = i.next();
                        System.out.println(e);
                    }
                    System.out.println("--------------------------");
                    break;
                case 3:
                    boolean found = false;
                    System.out.println("Enter Commune to Search");
                    int provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Villages e = i.next();
                        if (e.getNumOfVillages() == provincesId) {
                            System.out.println(e);
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    }
                    System.out.println("----------------");
                    break;
                case 4:
                    found = false;
                    System.out.println("Enter Commune to Delete");
                    numOfVillages = s.nextInt();
                    System.out.println("-----------------------");
                    i = c.iterator();
                    while (i.hasNext()) {
                        Villages e = i.next();
                        if (e.getNumOfVillages() == numOfVillages) {
                            i.remove();
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is deleted successfully");
                    }
                    System.out.println("----------------");
                    break;
                case 5:
                    found = false;
                    System.out.println("Enter Province to Update");
                    provincesId = s.nextInt();
                    System.out.println("-----------------------");
                    ListIterator<Villages> li = c.listIterator();
                    while (li.hasNext()) {
                        Villages e = li.next();
                        if (e.getNumOfVillages() == provincesId) {
                            System.out.println("Enter the new amount Communes");
                            numOfVillages = s.nextInt();
                            li.set(new Villages(numOfVillages, provincesId));
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found");
                    } else {
                        System.out.println("Record is updated successfully");
                    }
                    System.out.println("----------------");
                    break;
            }


        }while (ch != 0) ;
    }
}
